package database;

import helper.SerializationUtil;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import User.User;

public class ICrudImpl {

	// private java.sql.Connection connection;
	private static File file;
	private static List<User> listUsers = new ArrayList<User>();

	public boolean inser(User newUser) throws Exception {
		for (User user : listUsers) {
			System.out.println("Current users: " + user.getName() + "pass"
					+ user.getPassword());
			if (user.getUserName().equals(newUser.getUserName())) {
				System.out.println("User already exist");
				return false;
			}
		}
		listUsers.add(newUser);

		saveUsers();

		return true;
	}

	public User getUser(String userName, String password) throws IOException,
			ClassNotFoundException {
		for (User user : listUsers) {
			System.out.println("Current users: " + user.getName() + "pass" + user.getPassword());
			if (user.getUserName().equals(userName) && user.getPassword().equals(password)) {
				System.out.println("User already exist");
				return user;
			}
		}
		return null;
	}

	public void openConnection() throws IOException {
		file = new File("D:\\testFile.txt");
		if (!file.exists()) {
			System.out.println("File do not exist, creating the file...");
			file.createNewFile();
		}

		/*
		 * try { Class.forName("com.mysql.jdbc.Driver"); this.connection=
		 * DriverManager.getConnection("jdbc:mysql://localhost/java_db","root",
		 * ""); System.out.println("Sucsessful conection with the database"); }
		 * catch (Exception e) { // TODO: handle exception
		 * System.out.println("Error" + e.getMessage()); }
		 */

	}

	@SuppressWarnings("unchecked")
	public static void loadUsers() throws IOException, ClassNotFoundException {
		file = new File("D:\\testFile.txt");
		if (!file.exists()) {
			System.out.println("File do not exist, creating the file...");
			// file.createNewFile();
		} else {
			listUsers = (List<User>) SerializationUtil.deserialize(file);
		}
	}

	private static void saveUsers() throws IOException, ClassNotFoundException {
		file = new File("C:\\testFile.txt");
		if (!file.exists()) {
			System.out.println("File do not exist, creating the file...");
			file.createNewFile();
		}
		SerializationUtil.serialize(listUsers, file);
	}

}
