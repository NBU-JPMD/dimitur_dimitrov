package database;

import User.User;

public interface ICrud {

	boolean inser(User user);

	User getUser(String userName, String password);
	
}
