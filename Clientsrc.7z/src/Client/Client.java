package Client;

import helper.FileSender;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Scanner;

public class Client {
	public static void client() throws IOException {
		InetSocketAddress crunchifyAddr = new InetSocketAddress("localhost",
				4446);
		SocketChannel crunchifyClient = SocketChannel.open(crunchifyAddr);

		Scanner scan = new Scanner(System.in);
		String line = "";

		log("Connecting to Server on port 1111...");

		System.out.println("Please enter command");
		while (!(line.equals("stop"))) {
			line = scan.nextLine();
			try {

				if (line.startsWith("Upload")) {
					byte[] message = new String(line).getBytes();
					ByteBuffer buffer = ByteBuffer.wrap(message);
					crunchifyClient.write(buffer);
					
					FileSender.sendFile(crunchifyClient, line);
					log("sending file: " + line.substring(7));
				} else {
					byte[] message = new String(line).getBytes();
					ByteBuffer buffer = ByteBuffer.wrap(message);
					crunchifyClient.write(buffer);
					buffer.clear();
					log("sending: " + line);
				}

				ByteBuffer crunchifyBuffer = ByteBuffer.allocate(1024);
				crunchifyClient.read(crunchifyBuffer);
				String result = new String(crunchifyBuffer.array()).trim();
				log("reading: " + result);

			} catch (IOException e) {
				System.out.println("Read failed");
				e.printStackTrace();
				System.exit(-1);
			}
			// wait for 2 seconds before sending next message
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		scan.close();
		try {
			crunchifyClient.close();
			System.out.println("close client");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void log(String str) {
		System.out.println(str);
	}
}
