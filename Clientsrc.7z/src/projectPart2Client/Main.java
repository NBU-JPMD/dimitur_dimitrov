package projectPart2Client;

import java.io.IOException;

import Client.Client;
import Ui.Login;
import database.ICrudImpl;

public class Main {

    /**
     * @param args the command line arguments
     * @throws IOException 
     */
    public static void main(String[] args) throws IOException {
    	try {
			ICrudImpl.loadUsers();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
    	Login login = new Login();
        login.setVisible(true);
        
    }
}