package helper;

import java.io.IOException;

import database.ICrudImpl;
import User.User;



public class Controller {

    private static Controller controller;
    private final ICrudImpl iCrudImpl;

    
    private Controller() throws IOException {
        this.iCrudImpl = new ICrudImpl();
        this.iCrudImpl.openConnection();
    }

    public static Controller getController() throws IOException {
        if (controller == null) {
            controller = new Controller();
        }
        return controller;
    }

    public boolean signup(User user) throws Exception {
    	
        return this.iCrudImpl.inser(user);
    }

    public User login(String username, String password) throws IOException, ClassNotFoundException {
        return this.iCrudImpl.getUser(username, password);
    }
}
/* 
 import User.User;
 
import database.ICrudImpl;

public class Controller {
private static Controller controller; 
private ICrudImpl iCrudImpl;
private Controller(){
	this.iCrudImpl = new ICrudImpl();
	this.iCrudImpl.openConnection();
	
}

public static Controller getController(){
	if (controller == null) {
		controller = new Controller();
	}
	return controller;
	
}

public boolean signup(User user) {
	return this.iCrudImpl.inser(user);
}
}
*/