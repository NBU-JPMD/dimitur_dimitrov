package User;

import java.io.IOException;

public interface UserInteractionListener {
 boolean signup(User user) throws IOException;
}
