package Util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileManager {

	public static Charset charset = Charset.forName("UTF-8");
	public static CharsetEncoder encoder = charset.newEncoder();
	public static CharsetDecoder decoder = charset.newDecoder();

	public static boolean UploadFile(SocketChannel socketChannel,
			ByteBuffer byteBuffer, String header) {
		RandomAccessFile aFile = null;
		boolean result = false;
		try {

			ByteBuffer buffer = ByteBuffer.allocate(1024);

			header = header.replaceFirst("Upload ", "");
			String ffname = header.replaceFirst("\\*", "").trim();
			String newFileName = ffname.substring(0, ffname.indexOf("*"));
			Path p = Paths.get(newFileName);
			aFile = new RandomAccessFile("D:\\Test\\"
					+ p.getFileName().toString(), "rw");
			FileChannel fileChannel = aFile.getChannel();

			fileChannel.write(StrToByteBuffer(ffname.substring(ffname
					.indexOf("*") + 1)));
			while (socketChannel.read(buffer) > 0) {
				buffer.flip();
				fileChannel.write(buffer);
				buffer.clear();
				result = true;
			}
			fileChannel.close();
			System.out
					.println("End of file reached..File uploaded succesfully!");
			return result;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	private static ByteBuffer StrToByteBuffer(String input) {
		ByteBuffer buf = ByteBuffer.allocate(1024);
		return ByteBuffer.wrap(input.getBytes(charset));
	}
	
	public static String  GetFileNames(){
		String result = new String();
		File[] files = new File("D:\\Test\\").listFiles();
		for (File file : files) {
		    if (file.isFile()) {
		    	result += file.getName() + ";";
		    }
		}
		return result;
	}
	
	public static String SearchFileNames(String fileSearch){
		String result = new String();
		fileSearch = fileSearch.replaceAll("Search file ", "");
		File[] files = new File("D:\\Test\\").listFiles();
		for (File file : files) {
		    if (file.isFile() && (file.getName().indexOf(fileSearch) >=0)) {
		    	result += file.getName() + ";";
		    }
		}
		return result;
	}
}
